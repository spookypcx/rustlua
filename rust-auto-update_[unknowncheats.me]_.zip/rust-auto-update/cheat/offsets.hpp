#pragma once

namespace offsets {
    uintptr_t Il2cppHandle;
    namespace BaseNetworkable {
        uintptr_t BaseNetworkable_C , static_fields , wrapper_class_ptr , parent_static_fields , entity;
    }
    namespace camera {
        uintptr_t MainCamera_C , MainCamera_Chain1 , MainCamera_Chain2 , MainCamera_Chain3;
    }
}